var a = 25;
a = a - 13;
console.log(a/2);
    
a = "hello";
console.log(a + " hello");


